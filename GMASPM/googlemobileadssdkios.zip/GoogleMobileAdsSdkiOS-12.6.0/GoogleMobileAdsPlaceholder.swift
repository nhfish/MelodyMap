// Copyright 2024 Google LLC

// The Google Mobile Ads SDK relies on Swift standard libraries. Apps that have no other Swift usage
// may see build time errors due to missing Swift libraries. For those apps, including this
// placeholder file ensures that Swift standard libraries are included automatically.